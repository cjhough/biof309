#modified HW for WK_2 to calculate percent AT content in DNA sequence

new_dna = open('dna_wk2.txt')
dna_seq = new_dna.read().rstrip('\n')

AT_content = 100*(dna_seq.count("A") + dna_seq.count("T")) / len(dna_seq)\
#counts 'A' and 'T' residues in sequence and calculates the AT% content

print('The AT content is',round(AT_content,2),'%')\
#prints calculated AT% in DNA, rounded to two decimal places
