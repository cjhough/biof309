#HW for WK_2 to calculate percent AT content in DNA sequence

new_dna = "ACTGATCGATTACGTATAGTATTTGCTATCATACATATATATCGATGCGTTCAT"\
#input DNA sequence as variable

#new_dna = input("DNA Sequence: ")\
#or input sequence at command line in terminal

AT_content = 100*(new_dna.count("A") + new_dna.count("T")) / len(new_dna)\
#counts 'A' and 'T' residues in sequence and calculates the AT% content

print('The AT content is',round(AT_content,2),'%')\
#prints calculated AT% in DNA, rounded to two decimal places
