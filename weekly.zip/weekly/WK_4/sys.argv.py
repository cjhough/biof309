import sys

print("This is the name of the script:", sys.argv[0])
print("And this is its path:", sys.path[0])
print("Number of arguments:", len(sys.argv))
print("The arguments are:", str(sys.argv))
print("Number of paths", len(sys.path))
print("The arguments are:", str(sys.argv))
print("The paths are", str(sys.path))
