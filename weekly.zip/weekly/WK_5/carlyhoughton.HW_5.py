import carlyhoughton.HW5_module as module

protein_seq = "MSRSLLLRFLLFLLLLPPLP"

assert module.amino_acid_percentage(protein_seq,"M") == 5
assert module.amino_acid_percentage(protein_seq,"r") == 10
assert module.amino_acid_percentage(protein_seq,"L") == 50
assert module.amino_acid_percentage(protein_seq,"Y") == 0

print(module.amino_acid_percentage(protein_seq,"M") == 5)
print(module.amino_acid_percentage(protein_seq,"r") == 10)
print(module.amino_acid_percentage(protein_seq,"L") == 50)
print(module.amino_acid_percentage(protein_seq,"Y") == 0)
