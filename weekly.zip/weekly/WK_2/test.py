#This is a print statement
print("Hello 'World'")

#This uses single quotes
print('Hello "World"')

#FIX This function is broken
print("This is a long python statement \
that needs to be wrapped") #here is my secret comment

message = "Hello World"
