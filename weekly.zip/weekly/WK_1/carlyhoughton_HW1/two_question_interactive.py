##Two question interactive
#name and place of origin
name=input("What is your name?: ")
print("Hello " + name)
origin=input("Where are from? ")
print("Nice to meet you " + name + " from " + origin +"!")