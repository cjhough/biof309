import sys
#usuage [script_name].py [trim length]

my_dna = open ("input.txt", "r")
trimmed_dna = open("output.txt",'w')
print("Number of arguments:", len(sys.argv))
print("The arguments are:", str(sys.argv))

for line in my_dna:

    last_position = len(line)
    trimmed_seq = line[int(sys.argv[1]):last_position]
    trimmed_dna.write(trimmed_seq)
    trimmed_length = len(trimmed_seq)
    print("The trimmed length is:", trimmed_length)

trimmed_dna.close()
