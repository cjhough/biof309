#methods to use with strings
new_dna = 'atgtag'

#in will look in a string and return true or false
print('a' in new_dna)

#str.upper#str.lower converts upper and lower case
print(new_dna.upper())
