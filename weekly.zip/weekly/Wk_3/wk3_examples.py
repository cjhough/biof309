#methods with files

#Read files
my_file = open('out.txt', 'w')
file_contents = my_file.read()
print(file_contents)

#read files methods
#every line ends with \n so have to use rstrip() function
my_dna = file_contents.rstrip('\n')

#and to string methods together
my_dna = my_file.read().rstrip('\n')
dna_length = len(my_dna)
print("sequence is " + my_dna + "and the length is" + str(dna_length))

#write files
my_file.write()
##need to add new lines, otherwise it will write all to one line

my_file.write("my_dna.upper()\n")
#remember to close the file
my_file.close()
