def amino_acid_percentage(x,a):
    sequence = x
    amino_acid = a
    count_a = sequence.count(amino_acid.upper())
    total_residues = len(sequence)
    percent_of_protein = round(100*(count_a/total_residues),0)
    return (percent_of_protein)
