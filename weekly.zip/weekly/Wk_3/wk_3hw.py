
#headers
header_1 = "ABC123"
header_2 = "DEF456"
header_3 = "HIJ789"

#sequences
dnaseq_1 = "ATCGTACGATCGATCGATCGCTAGACGTATCG"
dnaseq_2 = "actgatcgacgatcgatcgatcacgact"
dnaseq_3 = "ACTGAC-ACTGT--ACTGTA----CATGTG"

#open new file to write to
new_file = open("new_seq.fasta",'w')

#write each sequence in correct format and add to new fasta file
new_file.write('>' + header_1 + '\n' + dnaseq_1 +'\n')
new_file.write('>' + header_2 + '\n' + dnaseq_2.upper() +'\n')
new_file.write('>' + header_3 + '\n' + dnaseq_3.replace('-','') + '\n')

#close new file
new_file.close()
