import sys
#usuage [script_name].fasta.py [output_filename]

#DNA headers
header_1 = "ABC123"
header_2 = "DEF456"
header_3 = "HIJ789"

#DNA sequence variables
seq_1 = "ATCGTACGATCGATCGATCGCTAGACGTATCG"
seq_2 = "actgatcgacgatcgatcgatcacgact"
seq_3 = "ACTGAC-ACTGT--ACTGTA----CATGTG"

#open new file to write output to and set as variable
new_file = open(sys.argv[1],'w')

#write each sequence in correct format and add to new fasta file
my_file.write('>' + header_1 + '\n' + seq_1 +'\n')
my_file.write('>' + header_2 + '\n' + seq_2.upper() +'\n')
my_file.write('>' + header_3 + '\n' + seq_3.replace('-','') + '\n')

#close new file
my_file.close()
