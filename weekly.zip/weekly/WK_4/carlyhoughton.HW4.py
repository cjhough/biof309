import sys

#usuage [script_name].py [input_filename].txt [trim length]

# open the input file and output file
my_dna = open (sys.argv[1], "r")
trimmed_dna = open((sys.path[1] + "trim_seqs.txt"),'w')
print("Number of arguments:", len(sys.argv))
print("The arguments are:", str(sys.argv))

#go through the input file one line at a time
for line in my_dna:

    # calculate the position of the last character
    last_position = len(line)
    # get the substring from the 15th character to the end
    trimmed_seq = line[int(sys.argv[2]):last_position]
    trimmed_dna.write(trimmed_seq.upper())
    trimmed_length = len(trimmed_seq)
    # print out the trimmed sequence
    # print out the length to the screen
    print("The trimmed length is:", trimmed_length)

trimmed_dna.close()
